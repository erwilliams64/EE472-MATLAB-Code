
void HCSR04Sonar_Init(int trigger_pin, int echo_pin);
void HCSR04Sonar_Read(float* pfData);

