 #ifdef __cplusplus
extern "C" {
#endif

void float2bytes(unsigned char* pfData, float fin);

#ifdef __cplusplus
}
#endif


